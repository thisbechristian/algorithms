========================================
CS/COE 1501 Assignment Information Sheet
----------------------------------------

You must submit an information sheet with every assignment.  Also be sure
to submit all materials following the procedures described on the
submission procedures page.

Name: Christian Boni

Lecture section:  T/H 1PM

Recitation day and time:  F 10AM

Assignment #:  2

Program due date:  October 29th

Handed in date:  October 28th

Source code file name(s):
MyLZW.java
BinaryStdIn.java
BinaryStdOut.java
TST.java
Queue.java
StdIn.java
StdOut.java


Other file name(s) (if relevant):
None.


Does your program run without error?:
Yes

If not, what is/are the error(s) and which parts of your program run
correctly?:
None.


Additional comments to the grader:
None.





