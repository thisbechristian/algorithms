========================================
CS/COE 1501 Assignment Information Sheet
----------------------------------------

You must submit an information sheet with every assignment.  Also be sure
to submit all materials following the procedures described on the
submission procedures page.

Name: Christian Boni

Lecture section:  T/H 1PM

Recitation day and time:  F 10AM

Assignment #:  3

Program due date:  November 22nd

Handed in date:  November 21st

Source code file name(s):
SecureChatClient.java
SecureChatClient.java
SymCipher.java
Add128.java
Substitute.java

Other file name(s) (if relevant):
keys.txt


Does your program run without error?:
Yes

If not, what is/are the error(s) and which parts of your program run
correctly?:
None.


Additional comments to the grader:
None.





